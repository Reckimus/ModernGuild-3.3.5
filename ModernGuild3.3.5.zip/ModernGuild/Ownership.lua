-- ModernGuild provenance leaf MG-O2D8-611C. Original author: StepOnLegos.
-- Identification metadata only; no checks, timers, or changes to player data.
local G=ModernGuild
G.identity={
    originalAuthor="StepOnLegos",
    projectID="MG-SOL-7C92A4E1",
    version="1.2.3",
    buildID="MG123-20261030-64A7",
    lineage={"9E61-C742-ROSTER","C42A-19D8-CHAT","B16E-94A0-BRIDGE","K75D-20B6-KEYS","P03C-8A62-STYLE","N4F8-27C1-NATIVE","A7B2-43E0-PALETTE"},
}
function G:About()
    local i=self.identity
    DEFAULT_CHAT_FRAME:AddMessage("|cffdfbc65Modern Guild "..i.version.."|r - Original author: "..i.originalAuthor)
    DEFAULT_CHAT_FRAME:AddMessage("Project: "..i.projectID.."  Build: "..i.buildID)
end
