-- ModernGuild / StepOnLegos / MG-SOL-7C92A4E1
-- Native-frame bridge leaf MG-N4F8-27C1. No message interception or filter rewrites.
local G=ModernGuild
local N={saved={},order={},active=false,moving=false}
G.nativeChat=N
local builtins={{"GUILD","Guild"},{"OFFICER","Officer"},{"PARTY","Party"},{"RAID","Raid"},{"BATTLEGROUND","Battleground"},{"SAY","Say"},{"YELL","Yell"},{"WHISPER","Whisper"}}
local function protected(f)return f and f.IsProtected and f:IsProtected()end
local function frame(f)return f and f.GetParent and f.GetFrameLevel and f.GetNumPoints end
local function msg(s)DEFAULT_CHAT_FRAME:AddMessage("|cffdfbc65Modern Guild:|r "..s)end
function N:Config()
    G.db.chatDock=type(G.db.chatDock)=="table" and G.db.chatDock or {}
    local c=G.db.chatDock
    if c.enabled==nil then c.enabled=true end
    if c.hideExternal==nil then c.hideExternal=true end
    c.windows=type(c.windows)=="table" and c.windows or {}
    c.channels=type(c.channels)=="table" and c.channels or {}
    return c
end
function N:Windows()
    local out={}
    for i=1,(NUM_CHAT_WINDOWS or 10)do
        local f=_G["ChatFrame"..i]
        local name=GetChatWindowInfo and GetChatWindowInfo(i)
        if frame(f) and type(name)=="string" and name~="" then out[#out+1]={id=i,name=name,frame=f}end
    end
    return out
end
function N:Channels()
    local out={}
    for _,v in ipairs(builtins)do out[#out+1]={key=v[1],type=v[1],label=v[2]}end
    local values=GetChannelList and {GetChannelList()} or {}
    local i=1
    while i<=#values do
        local id,name=values[i],values[i+1]
        if type(id)=="number" and type(name)=="string"then out[#out+1]={key="CHANNEL:"..name:lower(),type="CHANNEL",label=name,name=name}end
        i=i+(type(values[i+2])=="boolean" and 3 or 2)
    end
    return out
end
function N:Remember(f)
    if not frame(f) or protected(f) then return false end
    if self.saved[f]then return true end
    local s={parent=f:GetParent(),points={},w=f:GetWidth(),h=f:GetHeight(),scale=f:GetScale(),strata=f:GetFrameStrata(),level=f:GetFrameLevel(),shown=f:IsShown(),alpha=f.GetAlpha and f:GetAlpha() or 1}
    for i=1,f:GetNumPoints()do s.points[i]={f:GetPoint(i)}end
    self.saved[f]=s;self.order[#self.order+1]=f
    return true
end
function N:Park(f)
    if self:Remember(f)and f:GetParent()~=self.parking then f:SetParent(self.parking)end
end
function N:InputFor(f)
    local name=f and f:GetName()
    return f and (f.editBox or (name and _G[name.."EditBox"]) or _G.ChatFrameEditBox)
end
function N:Move(f,parent,top,bottom)
    if not self:Remember(f)then return false end
    if f:GetParent()~=parent then f:SetParent(parent)end
    f:SetScale(UIParent:GetEffectiveScale()/parent:GetEffectiveScale())
    f:ClearAllPoints();f:SetPoint("TOPLEFT",parent,"TOPLEFT",top or 0,0);f:SetPoint("BOTTOMRIGHT",parent,"BOTTOMRIGHT",bottom or 0,0)
    f:SetFrameStrata("DIALOG");f:SetFrameLevel(G.frame:GetFrameLevel()+12);f:SetAlpha(1);f:Show()
    return true
end
function N:Start()
    if self.active or not self:Config().enabled or not G.frame:IsShown() or #self:Windows()==0 then return end
    self.active=true;self.saved={};self.order={}
    self.previousSelected=SELECTED_CHAT_FRAME
    if self.previousSelected and protected(self.previousSelected)then self.active=false;return end
    self:ApplyView()
end
function N:Stop()
    if not self.active then return end
    self.active=false;self.moving=true
    G.chatTab:SetText("Guild Chat")
    if self.editBox then self.editBox:ClearFocus()end
    for i=#self.order,1,-1 do
        local f=self.order[i];local s=self.saved[f]
        if s and (not protected(f) or not (InCombatLockdown and InCombatLockdown()))then
            f:SetParent(s.parent);f:SetScale(s.scale);f:SetSize(s.w,s.h);f:SetFrameStrata(s.strata);f:SetFrameLevel(s.level)
            f:ClearAllPoints();for _,p in ipairs(s.points)do f:SetPoint(unpack(p))end
            f:SetAlpha(s.alpha)
            if s.font then f:SetFont(unpack(s.font))end
            if s.spacing~=nil then f:SetSpacing(s.spacing)end
            if s.shown then f:Show()else f:Hide()end
        end
    end
    if self.changedSelection and self.previousSelected and FCF_SelectDockFrame and SELECTED_CHAT_FRAME~=self.previousSelected then FCF_SelectDockFrame(self.previousSelected)end
    self.changedSelection=nil
    self.saved={};self.order={};self.editBox=nil;self.selected=nil;self.lastSelectedFrame=nil;self.moving=false
    if self.bar then self.bar:Hide()end
end
function N:ChooseWindow(id)
    local restart=self.active and not self:Config().hideExternal
    if restart then self:Stop()end
    self:Config().selected=id;G:ShowMode("CHAT")
    if restart then self:Start()end
end
function N:ApplyView()
    if self.moving or not self.active then return end
    self.moving=true
    local c=self:Config();local windows=self:Windows();local chosen
    for _,w in ipairs(windows)do if c.windows[w.id]~=false and w.id==c.selected and not protected(w.frame)then chosen=w end end
    if c.selected~="HISTORY" and not chosen then
        for _,w in ipairs(windows)do if c.windows[w.id]~=false and not protected(w.frame)then chosen=w;break end end
    end
    if c.selected~="HISTORY" and not chosen then c.selected="HISTORY"end
    self.selected=chosen and chosen.frame or nil
    self.editBox=nil
    local inChat=G.mode=="CHAT"
    if self.selected and self.selected~=self.lastSelectedFrame then
        -- Capture homes before native tab selection updates dock geometry.
        for _,w in ipairs(windows)do
            local f=w.frame;local name=f:GetName()
            if (c.hideExternal or f==self.selected or self.saved[f])and not protected(f)then
                self:Remember(f);self:Remember(_G[name.."Tab"]);self:Remember(_G[name.."ButtonFrame"]);self:Remember(self:InputFor(f))
            end
        end
        if c.hideExternal then
            for _,name in ipairs({"GeneralDockManager","ChatFrameMenuButton","ChatFrameChannelButton","ChatFrameToggleVoiceMuteButton"})do self:Remember(_G[name])end
        end
        self.lastSelectedFrame=self.selected
        if FCF_SelectDockFrame and SELECTED_CHAT_FRAME~=self.selected then self.changedSelection=true;FCF_SelectDockFrame(self.selected)end
    end
    for _,w in ipairs(windows)do
        local f=w.frame;local name=f:GetName()
        if (c.hideExternal or f==self.selected or self.saved[f])and not protected(f)then
            if inChat and f==self.selected then self:Move(f,self.holder)
            else self:Park(f)end
            for _,suffix in ipairs({"Tab","ButtonFrame"})do
                local part=_G[name..suffix]
                self:Park(part)
            end
            local edit=self:InputFor(f)
            if inChat and f==self.selected and self:Remember(edit)then
                self.editBox=edit
                self:Move(edit,G.inputBox,10,-54)
                if not edit._modernGuildFocusHook then
                    edit._modernGuildFocusHook=true
                    edit:HookScript("OnEnterPressed",function(box)
                        if N.active and N.editBox==box and G.mode=="CHAT" and G:Appearance().keepFocus then box:SetFocus()end
                    end)
                end
            elseif edit~=self.editBox then self:Park(edit)end
        end
    end
    if c.hideExternal then
        for _,name in ipairs({"GeneralDockManager","ChatFrameMenuButton","ChatFrameChannelButton","ChatFrameToggleVoiceMuteButton"})do self:Park(_G[name])end
    end
    self.bar:Show();G.channelTitle:Hide()
    local barWidth=math.max(220,G.center:GetWidth()-20)
    self.viewButton:SetWidth(math.min(175,(barWidth-8)/2));self.channelButton:SetWidth(math.min(165,(barWidth-8)/2))
    self.viewButton:SetText(chosen and chosen.name or "Guild Chat")
    if inChat and chosen and self.editBox then
        G.chat:Hide();G.chatEmpty:Hide();G.jump:Hide();G.input:Hide();G.inputPrefix:Hide()
        G.channelTitle:Hide();self.channelButton:Show()
        self.channelButton:SetText("Send: "..self:CurrentChannelLabel())
    elseif inChat then
        G.chat:Show();G.chatEmpty:Show();G.input:Show();G.inputPrefix:Show();G.channelTitle:Hide();self.channelButton:Hide()
        G.chat:ClearAllPoints();G.chat:SetPoint("TOPLEFT",G.center,"TOPLEFT",14,-44);G.chat:SetPoint("BOTTOMRIGHT",G.center,"BOTTOMRIGHT",-14,64)
        G.chatEmpty:ClearAllPoints();G.chatEmpty:SetPoint("TOPLEFT",G.center,"TOPLEFT",14,-50)
    else self.channelButton:Hide()end
    if G.AdvancedLayout then G:AdvancedLayout()end
    self.moving=false
end
function N:CurrentChannelLabel()
    local b=self.editBox
    if not b or not b.GetAttribute then return "Guild"end
    local kind=b:GetAttribute("chatType") or "SAY"
    if kind=="CHANNEL"then
        local id=b:GetAttribute("channelTarget")
        for _,v in ipairs(self:Channels())do if v.type=="CHANNEL"and GetChannelName and GetChannelName(v.name)==id then return v.label end end
        return "Channel "..tostring(id or "?")
    end
    if kind=="WHISPER"then return "Whisper "..(b:GetAttribute("tellTarget") or "")end
    for _,v in ipairs(builtins)do if v[1]==kind then return v[2]end end
    return kind
end
function N:SetChannel(v,target)
    local b=self.editBox;if not b or not b.SetAttribute then return end
    if v.type=="WHISPER" and not target then StaticPopup_Show("MODERNGUILD_CHAT_WHISPER");return end
    if (v.type=="GUILD"or v.type=="OFFICER")and not GetGuildInfo("player")then msg("You are not in a guild.");return end
    local channel
    if v.type=="CHANNEL"then
        channel=GetChannelName and GetChannelName(v.name)
        if not channel or channel==0 then msg("You are no longer in that channel.");return end
    end
    -- Leave the game's normal language, slash parser, whisper handling and
    -- Chatter edit-box hooks intact. Only the explicitly chosen send target changes.
    b:SetAttribute("chatType",v.type);b:SetAttribute("stickyType",v.type)
    if target then b:SetAttribute("tellTarget",target)end
    if channel then b:SetAttribute("channelTarget",channel)end
    if ChatEdit_UpdateHeader then ChatEdit_UpdateHeader(b)end
    self.channelButton:SetText("Send: "..self:CurrentChannelLabel());b:SetFocus()
end
function N:ViewMenu()
    local menu={{text="Chat Windows",isTitle=true,notCheckable=true}}
    for _,w in ipairs(self:Windows())do
        local id=w.id
        if self:Config().windows[id]~=false then menu[#menu+1]={text=w.name,checked=self.selected==w.frame,func=function()N:ChooseWindow(id)end}end
    end
    table.insert(menu,2,{text="Guild Chat",checked=self:Config().selected=="HISTORY",func=function()N:ChooseWindow("HISTORY")end})
    menu[#menu+1]={text="Guild Information",notCheckable=true,func=function()G:ShowMode("INFO")end}
    EasyMenu(menu,self.menu,"cursor",0,0,"MENU")
end
function N:ChannelMenu()
    local menu={{text="Send To",isTitle=true,notCheckable=true}}
    for _,v in ipairs(self:Channels())do
        local choice=v
        if self:Config().channels[v.key]~=false then menu[#menu+1]={text=v.label,notCheckable=true,func=function()N:SetChannel(choice)end}end
    end
    EasyMenu(menu,self.menu,"cursor",0,0,"MENU")
end
function N:Build()
    if self.bar then return end
    self.parking=CreateFrame("Frame","ModernGuildChatParking",UIParent);self.parking:Hide()
    self.holder=CreateFrame("Frame",nil,G.center);self.holder:SetPoint("TOPLEFT",14,-44);self.holder:SetPoint("BOTTOMRIGHT",-14,64)
    self.bar=CreateFrame("Frame",nil,G.center);self.bar:SetPoint("TOPLEFT",10,-8);self.bar:SetPoint("TOPRIGHT",-10,-8);self.bar:SetHeight(25);self.bar:SetFrameLevel(G.frame:GetFrameLevel()+15)
    self.viewButton=CreateFrame("Button",nil,self.bar,"UIPanelButtonTemplate");self.viewButton:SetSize(175,23);self.viewButton:SetPoint("LEFT");self.viewButton:SetText("Chat Windows");self.viewButton:SetScript("OnClick",function()N:ViewMenu()end)
    self.channelButton=CreateFrame("Button",nil,self.bar,"UIPanelButtonTemplate");self.channelButton:SetSize(165,23);self.channelButton:SetPoint("RIGHT");self.channelButton:SetScript("OnClick",function()N:ChannelMenu()end)
    self.menu=CreateFrame("Frame","ModernGuildChatChoiceMenu",UIParent,"UIDropDownMenuTemplate")
    self.bar:Hide()
    G.chatTab:SetScript("OnClick",function()N:ChooseWindow("HISTORY")end)
    local b=CreateFrame("Button",nil,G.frame,"UIPanelButtonTemplate");b:SetSize(90,23);b:SetPoint("BOTTOMLEFT",266,11);b:SetText("Channels");b:SetScript("OnClick",function()N:Settings()end)
    G.frame:HookScript("OnShow",function()N:Start()end)
    G.frame:HookScript("OnHide",function()N:Stop();if N.settings then N.settings:Hide()end end)
end
function N:Settings()
    G:CreateUI()
    if self.editBox then self.editBox:ClearFocus()end
    G.input:ClearFocus()
    if self.settings and self.settings:IsShown()then self.settings:Hide();return end
    if not self.settings then
        local f=CreateFrame("Frame","ModernGuildChannelSettings",UIParent);self.settings=f
        f:SetSize(430,590);f:SetPoint("CENTER");f:SetFrameStrata("DIALOG");f:SetFrameLevel(G.frame:GetFrameLevel()+50);f:SetClampedToScreen(true);f:EnableMouse(true)
        f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",tile=true,tileSize=16,edgeSize=12,insets={left=3,right=3,top=3,bottom=3}});f:SetBackdropColor(.05,.05,.05,1)
        local title=f:CreateFontString(nil,"OVERLAY","GameFontNormal");title:SetPoint("TOPLEFT",18,-18);title:SetText("Chat Dock & Channels")
        local close=CreateFrame("Button",nil,f,"UIPanelCloseButton");close:SetPoint("TOPRIGHT",-2,-2);close:SetScript("OnClick",function()f:Hide()end)
        UISpecialFrames[#UISpecialFrames+1]="ModernGuildChannelSettings"
        local note=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");note:SetPoint("TOPLEFT",18,-45);note:SetWidth(390);note:SetJustifyH("LEFT");note:SetText("Native windows keep their WoW / Chatter receive filters.\nReceive filters stay in WoW / Chatter settings.")
        f.scroll=CreateFrame("ScrollFrame","ModernGuildChannelSettingsScroll",f,"UIPanelScrollFrameTemplate");f.scroll:SetPoint("TOPLEFT",18,-90);f.scroll:SetPoint("BOTTOMRIGHT",-35,20)
        f.content=CreateFrame("Frame",nil,f.scroll);f.content:SetSize(370,1);f.scroll:SetScrollChild(f.content);f.rows={}
    end
    local f=self.settings;local rows={
        {label="Dock the game's existing chat windows",get=function()return N:Config().enabled end,set=function(v)N:Stop();N:Config().enabled=v;G:ShowMode(G.mode);if v and G.frame:IsShown()then N:Start()end end},
        {label="Hide other chat windows while this panel is open",get=function()return N:Config().hideExternal end,set=function(v)N:Stop();N:Config().hideExternal=v;if G.frame:IsShown()then N:Start()end end},
        {label="Windows in the view selector:",heading=true},
    }
    for _,w in ipairs(self:Windows())do local id=w.id;rows[#rows+1]={label=w.name,get=function()return N:Config().windows[id]~=false end,set=function(v)N:Config().windows[id]=v;N:ApplyView()end}end
    rows[#rows+1]={label="Channels in the Send To selector:",heading=true}
    for _,v in ipairs(self:Channels())do local key=v.key;rows[#rows+1]={label=v.label,get=function()return N:Config().channels[key]~=false end,set=function(on)N:Config().channels[key]=on end}end
    for i,spec in ipairs(rows)do
        local row=f.rows[i]
        if not row then
            row=CreateFrame("CheckButton",nil,f.content,"UICheckButtonTemplate");f.rows[i]=row;row:SetSize(24,24);row:SetPoint("TOPLEFT",0,-(i-1)*28)
            row.label=row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");row.label:SetPoint("LEFT",27,0);row.label:SetWidth(335);row.label:SetJustifyH("LEFT")
            row:SetScript("OnClick",function(self)if self.spec.set then self.spec.set(self:GetChecked()and true or false)end end)
        end
        row.spec=spec;row.label:SetText(spec.label);row:SetChecked(spec.get and spec.get()or false)
        if spec.heading then row:Disable()else row:Enable()end;row:Show()
    end
    for i=#rows+1,#f.rows do f.rows[i]:Hide()end
    f.content:SetHeight(#rows*28+5);f:Show();f:Raise()
end
local create=G.CreateUI
function G:CreateUI()create(self);N:Build()end
local open=G.Open
function G:Open()
    N:Config().selected="HISTORY";self.mode="CHAT"
    open(self);N:Start();self:ShowMode("CHAT")
end
local layout=G.Layout
function G:Layout()
    layout(self)
    if self.helpText then self.helpText:ClearAllPoints();self.helpText:SetPoint("BOTTOMLEFT",366,17);self.helpText:SetWidth(math.max(30,self.frame:GetWidth()-550));self.helpText:SetText("G: toggle")end
    if N.active then N:LayoutOnly()end
end
local mode=G.ShowMode
function G:ShowMode(value)
    mode(self,value)
    if N.bar then
        if N.active then N:ApplyView()
        else
            N.bar:Hide();self.inputPrefix:Show();self.channelTitle:Show()
            self.chat:ClearAllPoints();self.chat:SetPoint("TOPLEFT",self.center,"TOPLEFT",14,-40);self.chat:SetPoint("BOTTOMRIGHT",self.center,"BOTTOMRIGHT",-14,64)
            self.chatEmpty:ClearAllPoints();self.chatEmpty:SetPoint("TOPLEFT",self.center,"TOPLEFT",14,-46)
        end
    end
end
local send=G.Send
function G:Send()
    if N.active and N.editBox and self.mode=="CHAT"then
        local handler=N.editBox:GetScript("OnEnterPressed")
        if handler then handler(N.editBox)end
    else send(self)end
end
local slash=G.Slash
function G:Slash(value)
    local cmd=(value or ""):match("^%s*(%S*)"):lower()
    if cmd=="channels" or cmd=="chat"then N:Settings()else slash(self,value)end
end
StaticPopupDialogs.MODERNGUILD_CHAT_WHISPER={text="Whisper player name",button1=ACCEPT,button2=CANCEL,hasEditBox=true,maxLetters=64,timeout=0,whileDead=true,hideOnEscape=true,
    OnAccept=function(self)local name=self.editBox:GetText():match("^%s*(.-)%s*$");if name~=""then N:SetChannel({type="WHISPER"},name)end end,
    OnShow=function(self)self.editBox:SetText("");self.editBox:SetFocus()end}
-- No polling/reparent loop: native input is only borrowed on an explicit
-- window change. Appearance edits adjust geometry without reopening edit boxes.
function N:LayoutOnly()
    if not self.active then return end
    local width=math.max(220,G.center:GetWidth()-20)
    self.viewButton:SetWidth(math.min(175,(width-8)/2));self.channelButton:SetWidth(math.min(165,(width-8)/2))
    for _,pair in ipairs({{self.selected,self.holder},{self.editBox,G.inputBox}})do
        local f,parent=pair[1],pair[2]
        if f and f:GetParent()==parent then
            local scale=UIParent:GetEffectiveScale()/parent:GetEffectiveScale()
            if math.abs(f:GetScale()-scale)>.0001 then f:SetScale(scale)end
        end
    end
end
