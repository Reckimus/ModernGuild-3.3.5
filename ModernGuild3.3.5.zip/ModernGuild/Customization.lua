-- ModernGuild appearance and responsive layout. StepOnLegos / MG-SOL-7C92A4E1.
-- Provenance P03C-8A62-STYLE; release leaf 46F1-A8D3 / MG123-20261030-64A7.
local G=ModernGuild
local defaults={fontSize=14,opacity=.9,theme="GOLD",leftWidth=176,rightWidth=236,timestamps=true,classColors=true,zones=true,keepFocus=true,locked=false}
local themes={
    GOLD={name="Classic Gold",bg={.075,.065,.05},edge={.48,.41,.28},accent={.94,.78,.43}},
    SLATE={name="Slate Blue",bg={.035,.055,.085},edge={.28,.43,.59},accent={.48,.74,1}},
    EMERALD={name="Emerald",bg={.025,.075,.05},edge={.24,.48,.34},accent={.4,.9,.58}},
}
function G:ThemePalette()return themes[self:Appearance().theme]end
local themeOrder={"GOLD","SLATE","EMERALD"}
local function clamp(n,lo,hi,otherwise)
    if type(n)~="number" or n~=n then return otherwise end
    return math.max(lo,math.min(hi,n))
end
function G:Appearance()
    self.db.appearance=type(self.db.appearance)=="table" and self.db.appearance or {}
    local a=self.db.appearance
    for k,v in pairs(defaults)do if a[k]==nil then a[k]=v end end
    a.fontSize=clamp(a.fontSize,11,20,14);a.opacity=clamp(a.opacity,.4,1,.9)
    a.leftWidth=clamp(a.leftWidth,140,220,176);a.rightWidth=clamp(a.rightWidth,200,320,236)
    if not themes[a.theme]then a.theme="GOLD"end
    return a
end
-- Size is saved independently of display scale; fitting never rewrites it.
function G:Layout()
    if not self.layoutReady or self.inLayout then return end
    self.inLayout=true
    local a=self:Appearance();local f=self.frame
    local w,h=f:GetWidth(),f:GetHeight()
    self.db.width=w;self.db.height=h
    local left=a.leftWidth
    local right=math.min(a.rightWidth,w-left-360)
    self.left:SetWidth(left);self.right:SetWidth(right)
    self.title:SetWidth(math.max(200,w-90))
    for _,t in ipairs({self.guildName,self.rank,self.total})do t:SetWidth(left-24)end
    self.chatTab:SetWidth(left-24);self.infoTab:SetWidth(left-24)
    self.motdContent:SetWidth(left-44);self.motdText:SetWidth(left-44)
    self.motdContent:SetHeight(math.max(1,self.motdText:GetStringHeight()+8))
    local center=w-left-right-40
    self.infoContent:SetWidth(math.max(240,center-48));self.infoText:SetWidth(math.max(240,center-48))
    self.infoContent:SetHeight(math.max(1,self.infoText:GetStringHeight()+16))
    self.chatEmpty:SetWidth(math.max(200,center-28))
    self.channelTitle:SetWidth(math.max(140,center-28))
    self.search:SetWidth(right-34);self.searchHint:SetWidth(right-50)
    self.rosterTitle:SetWidth(right-95)
    local count=math.max(1,math.floor((h-197)/34))
    self:EnsureRosterRows(count)
    for _,row in ipairs(self.rows)do
        row:SetWidth(right-40);row.name:SetWidth(right-93);row.detail:SetWidth(right-62)
    end
    self:FilterMembers()
    local font,_,flags=ChatFontNormal:GetFont()
    self.chat:SetFont(font,a.fontSize,flags or "");self.input:SetFont(font,a.fontSize,flags or "")
    local theme=themes[a.theme]
    for _,panel in ipairs({f,self.left,self.center,self.right,self.inputBox})do
        panel:SetBackdropColor(theme.bg[1],theme.bg[2],theme.bg[3],panel==f and a.opacity*.35 or a.opacity)
        panel:SetBackdropBorderColor(theme.edge[1],theme.edge[2],theme.edge[3],math.min(1,a.opacity+.2))
    end
    self.title:SetTextColor(unpack(theme.accent));self.guildName:SetTextColor(unpack(theme.accent))
    self.channelTitle:SetTextColor(unpack(theme.accent));self.rosterTitle:SetTextColor(unpack(theme.accent))
    self.helpText:ClearAllPoints();self.helpText:SetPoint("BOTTOMLEFT",270,17);self.helpText:SetWidth(math.max(40,w-450))
    self.helpText:SetText(w>=920 and "G: toggle  |  Drag title / corner to move / resize" or "G: toggle")
    self.invite:ClearAllPoints();self.invite:SetPoint("BOTTOMRIGHT",-30,11)
    f:SetResizable(not a.locked);self.resizeGrip:EnableMouse(not a.locked)
    if a.locked then self.resizeGrip:SetAlpha(.3)else self.resizeGrip:SetAlpha(1)end
    self:Fit()
    self.inLayout=false
end
function G:ApplyAppearance(refreshChat)
    if not self.frame then return end
    self:Layout()
    if refreshChat then self:RebuildChat()end
end
local function label(parent,value,x,y,width)
    local t=parent:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    t:SetPoint("TOPLEFT",x,y);t:SetJustifyH("LEFT");t:SetWidth(width or 310);t:SetText(value);return t
end
function G:SyncSettings()
    if not self.settings then return end
    self.syncingSettings=true
    local a=self:Appearance()
    for key,slider in pairs(self.settings.sliders)do
        slider:SetValue(key=="scale" and (self.db.scale or 1) or a[key])
        local v=key=="scale" and (self.db.scale or 1) or a[key]
        slider.valueLabel:SetText(key=="opacity" and (math.floor(v*100+.5).."%") or key=="scale" and string.format("%.2f",v) or tostring(math.floor(v+.5)))
    end
    for key,check in pairs(self.settings.checks)do check:SetChecked(a[key])end
    self.settings.theme:SetText(themes[a.theme].name)
    self.syncingSettings=false
end
function G:OpenSettings()
    self:CreateUI()
    if self.settings and self.settings:IsShown()then self.settings:Hide();return end
    if not self.settings then
        local f=CreateFrame("Frame","ModernGuildSettings",UIParent);self.settings=f
        f:SetSize(380,590);f:SetPoint("CENTER");f:SetFrameStrata("DIALOG");f:SetFrameLevel(self.frame:GetFrameLevel()+40);f:SetClampedToScreen(true);f:EnableMouse(true)
        f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",tile=true,tileSize=16,edgeSize=12,insets={left=3,right=3,top=3,bottom=3}})
        f:SetBackdropColor(.055,.05,.04,1)
        label(f,"Modern Guild - Appearance",18,-18)
        local close=CreateFrame("Button",nil,f,"UIPanelCloseButton");close:SetPoint("TOPRIGHT",-2,-2);close:SetFrameLevel(f:GetFrameLevel()+10);close:SetScript("OnClick",function()f:Hide()end)
        UISpecialFrames[#UISpecialFrames+1]="ModernGuildSettings"
        label(f,"Theme",20,-54)
        f.theme=CreateFrame("Button",nil,f,"UIPanelButtonTemplate");f.theme:SetSize(180,23);f.theme:SetPoint("TOPLEFT",150,-48)
        f.theme:SetScript("OnClick",function()
            local a=G:Appearance()
            for i,k in ipairs(themeOrder)do if k==a.theme then a.theme=themeOrder[i%#themeOrder+1];break end end
            G:ApplyAppearance();G:SyncSettings()
        end)
        f.sliders={};f.checks={}
        local specs={{"fontSize","Chat font size",11,20,1},{"opacity","Background opacity",.4,1,.05},{"scale","Window scale",.65,1.25,.05},{"leftWidth","Guild sidebar width",140,220,4},{"rightWidth","Member sidebar width",200,320,4}}
        for i,spec in ipairs(specs)do
            local key,title,lo,hi,step=unpack(spec)
            local y=-94-(i-1)*50
            label(f,title,20,y)
            local slider=CreateFrame("Slider","ModernGuildStyle_"..key,f,"OptionsSliderTemplate")
            slider:SetSize(230,16);slider:SetPoint("TOPLEFT",25,y-22);slider:SetMinMaxValues(lo,hi);slider:SetValueStep(step)
            local low,high,titleText=_G[slider:GetName().."Low"],_G[slider:GetName().."High"],_G[slider:GetName().."Text"]
            if low then low:SetText("")end;if high then high:SetText("")end;if titleText then titleText:SetText("")end
            slider.valueLabel=label(f,"",285,y-22,62)
            slider:SetScript("OnValueChanged",function(_,value)
                if G.syncingSettings then return end
                value=lo+math.floor((value-lo)/step+.5)*step;value=math.max(lo,math.min(hi,value))
                if key=="scale"then G.db.scale=value else G:Appearance()[key]=value end
                slider.valueLabel:SetText(key=="opacity" and (math.floor(value*100+.5).."%") or key=="scale" and string.format("%.2f",value) or tostring(math.floor(value+.5)))
                G:ApplyAppearance()
            end)
            f.sliders[key]=slider
        end
        local checks={{"timestamps","Show chat timestamps"},{"classColors","Color player names by class"},{"zones","Show member zones"},{"keepFocus","Keep typing after sending"},{"locked","Lock window size"}}
        for i,spec in ipairs(checks)do
            local key,title=unpack(spec)
            local c=CreateFrame("CheckButton",nil,f,"UICheckButtonTemplate");c:SetSize(24,24);c:SetPoint("TOPLEFT",18,-354-(i-1)*28)
            local t=c:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");t:SetPoint("LEFT",26,0);t:SetText(title)
            c:SetScript("OnClick",function(self)G:Appearance()[key]=self:GetChecked() and true or false;G:ApplyAppearance(key=="timestamps" or key=="classColors")end)
            f.checks[key]=c
        end
        local reset=CreateFrame("Button",nil,f,"UIPanelButtonTemplate");reset:SetSize(150,24);reset:SetPoint("BOTTOMLEFT",20,52);reset:SetText("Reset Appearance")
        reset:SetScript("OnClick",function()G.db.appearance=nil;G:ApplyAppearance(true);G:SyncSettings()end)
        local size=CreateFrame("Button",nil,f,"UIPanelButtonTemplate");size:SetSize(150,24);size:SetPoint("BOTTOMRIGHT",-20,52);size:SetText("Reset Size / Position")
        size:SetScript("OnClick",function()G:Slash("reset");G:SyncSettings()end)
        local about=CreateFrame("Button",nil,f,"UIPanelButtonTemplate");about:SetSize(130,23);about:SetPoint("BOTTOM",0,16);about:SetText("About Modern Guild");about:SetScript("OnClick",function()G:About()end)
        f:Hide()
    end
    self:SyncSettings();self.settings:Show();self.settings:Raise()
end
-- Wrappers preserve the established chat, keybinding and stock-roster paths.
local createUI=G.CreateUI
function G:CreateUI()
    if self.layoutReady then return end
    createUI(self)
    self:Appearance()
    local f=self.frame
    f:SetResizable(true);f:SetMinResize(820,460);f:SetMaxResize(1600,1100)
    local grip=CreateFrame("Button","ModernGuildResizeGrip",f);self.resizeGrip=grip
    grip:SetSize(18,18);grip:SetPoint("BOTTOMRIGHT",-1,1);grip:SetFrameLevel(f:GetFrameLevel()+21);grip:EnableMouse(true)
    grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up");grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight");grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    grip:SetScript("OnMouseDown",function(_,which)if which=="LeftButton" and not G:Appearance().locked then G.resizing=true;f:StartSizing("BOTTOMRIGHT")end end)
    local function finish()
        if not G.resizing then return end
        f:StopMovingOrSizing();G.resizing=nil;G.db.position={x=f:GetLeft(),y=f:GetTop()};G:Layout()
    end
    grip:SetScript("OnMouseUp",finish);f:HookScript("OnHide",function()finish();if G.settings then G.settings:Hide()end end)
    local settings=CreateFrame("Button",nil,f,"UIPanelButtonTemplate");self.settingsButton=settings
    settings:SetSize(94,23);settings:SetPoint("BOTTOMLEFT",162,11);settings:SetText("Appearance");settings:SetScript("OnClick",function()G:OpenSettings()end)
    f:SetSize(clamp(self.db.width,820,1600,980),clamp(self.db.height,460,1100,580))
    self.layoutReady=true
    f:HookScript("OnSizeChanged",function()G:Layout()end)
    self:Layout()
end
local formatMessage=G.FormatMessage
function G:FormatMessage(r)
    local line=formatMessage(self,r)
    if self:Appearance().timestamps==false then line=line:gsub("^|cff777777.-|r ","",1)end
    return line
end
local send=G.Send
function G:Send()
    send(self)
    if not self:Appearance().keepFocus then self.input:ClearFocus()end
end
local slash=G.Slash
function G:Slash(msg)
    local cmd=(msg or ""):match("^%s*(%S*)"):lower()
    if cmd=="settings" or cmd=="appearance"then self:OpenSettings()
    elseif cmd=="about"then self:About()
    elseif cmd=="reset"then
        self:CreateUI();self.db.position=nil;self.db.scale=1;self.frame:SetSize(980,580)
        self.frame:ClearAllPoints();self.frame:SetPoint("CENTER");self:Layout()
    else slash(self,msg)end
end
