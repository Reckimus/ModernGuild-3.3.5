-- ModernGuild | Original author: StepOnLegos | Project MG-SOL-7C92A4E1
-- Lineage: 9E61-C742-ROSTER / build MG123-20261030-64A7
-- Modern-style guild layout, using only the legacy 3.3.5 guild/chat APIs.
local addonName=...
local G={members={},rows={},offset=0,mode="CHAT",elapsed=0}
ModernGuild=G
BINDING_HEADER_MODERNGUILD="Modern Guild"
BINDING_NAME_MODERNGUILD_TOGGLE="Toggle Guild Panel"
local WIDTH,HEIGHT,ROWS,ROW_H,LIMIT=980,580,11,34,300
local GOLD={.94,.78,.43}
local function say(s)DEFAULT_CHAT_FRAME:AddMessage("|cffdfbc65Modern Guild:|r "..s)end
local function guild()if G.demo then return G.demo.name,"Guild Master" end;return GetGuildInfo("player")end
local function short(name)return (name or ""):match("^[^-]+") or name or "" end
local function classColor(token)
    return (CUSTOM_CLASS_COLORS and CUSTOM_CLASS_COLORS[token or ""]) or (RAID_CLASS_COLORS and RAID_CLASS_COLORS[token or ""]) or {r=.94,g=.81,b=.49}
end
local function safe(s)local value=tostring(s or ""):gsub("|","||");return value end
local function text(parent,font,point,x,y,width)
    local t=parent:CreateFontString(nil,"OVERLAY",font or "GameFontHighlightSmall")
    t:SetPoint(point or "TOPLEFT",x or 0,y or 0);t:SetJustifyH("LEFT")
    if width then t:SetWidth(width)end
    return t
end
local function backdrop(f,dark)
    f:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",tile=true,tileSize=16,edgeSize=12,insets={left=3,right=3,top=3,bottom=3}})
    f:SetBackdropColor(dark and .025 or .075,dark and .035 or .065,dark and .03 or .05,.98)
    f:SetBackdropBorderColor(.43,.39,.29,1)
end
local function button(parent,label,width,fn)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate");b:SetSize(width,23);b:SetText(label);b:SetScript("OnClick",fn);return b
end
function G:GetHistory()
    if self.demo then return self.demo.history end
    local name=guild();if not name then return nil end
    self.db.history[name]=self.db.history[name] or {}
    return self.db.history[name]
end
function G:RequestRoster()
    if not self.demo and guild() and (not self.lastRequest or GetTime()-self.lastRequest>=10)then self.lastRequest=GetTime();GuildRoster()end
end
-- StepOnLegos lineage MG-C42A-19D8
function G:FormatMessage(r)
    local name=safe(short(r.author))
    local author="|Hplayer:"..r.author.."|h["..name.."]|h"
    local color=self.db.appearance and self.db.appearance.classColors==false and {r=.85,g=.85,b=.85} or classColor(r.class)
    local hex=string.format("%02x%02x%02x",math.floor(color.r*255+.5),math.floor(color.g*255+.5),math.floor(color.b*255+.5))
    return "|cff777777"..date("%H:%M",r.at).."|r |cff"..hex..author.."|r: |cff40ed77"..r.message.."|r"
end
function G:RebuildChat()
    if not self.frame then return end
    self.chat:Clear()
    local history=self:GetHistory() or {}
    for _,r in ipairs(history)do self.chat:AddMessage(self:FormatMessage(r),.25,.93,.47)end
    self.chat:ScrollToBottom();self.jump:Hide();self.unread=0
    self.chatEmpty:SetText(not guild() and "You are not in a guild." or (#history==0 and "No messages yet. Guild chat will appear here." or ""))
end
function G:AddChat(message,author,...)
    if not self.db or not guild() or type(message)~="string" or type(author)~="string" or author=="" then return end
    local realGuild=GetGuildInfo("player")
    if self.demo and not realGuild then return end
    local history
    if self.demo then self.db.history[realGuild]=self.db.history[realGuild] or {};history=self.db.history[realGuild]
    else history=self:GetHistory()end
    local token
    for _,m in ipairs(self.members)do if short(m.name)==short(author)then token=m.token;break end end
    local r={message=message,author=author,at=time(),class=token}
    history[#history+1]=r;while #history>LIMIT do table.remove(history,1)end
    if self.demo or not self.frame then return end
    if self.displayGuild~=guild()then self.displayGuild=guild();self:RebuildChat();return end
    local bottom=self.chat:AtBottom()
    self.chat:AddMessage(self:FormatMessage(r),.25,.93,.47)
    self.chatEmpty:SetText("")
    if bottom then self.chat:ScrollToBottom()
    else self.unread=(self.unread or 0)+1;self.jump:SetText(self.unread.." new - latest");self.jump:Show()end
end
-- StepOnLegos lineage MG-S83F-762C
function G:Send()
    local msg=self.input:GetText():match("^%s*(.-)%s*$")
    if msg=="" then self.input:SetFocus();return end
    if not guild() then say("Join a guild before sending guild chat.");return end
    msg=msg:gsub("^/[gG]%s+",""):gsub("^/[gG][uU][iI][lL][dD]%s+","")
    if msg:sub(1,1)=="/" then say("This box sends guild chat. Use the normal chat box for slash commands.");return end
    if #msg>255 then say("That message is too long (255 bytes maximum).");return end
    SendChatMessage(msg,"GUILD")
    self.input:SetText("");self.input:SetFocus()
end
function G:ReadRoster()
    self.members={};self.byName={}
    local name,rank=guild()
    local count=self.demo and #self.demo.members or (name and (GetNumGuildMembers(true) or 0) or 0)
    local online=0
    for i=1,count do
        local n,r,ri,level,class,zone,note,officer,connected,status,token
        if self.demo then
            local m=self.demo.members[i]
            n,r,ri,level,class,zone,note,connected,status,token=m.name,m.rank,m.rankIndex,m.level,m.class,m.zone,m.note,m.online,m.status,m.token
        else n,r,ri,level,class,zone,note,officer,connected,status,token=GetGuildRosterInfo(i)end
        if n then
            connected=connected and connected~=0
            local m={name=n,rank=r,rankIndex=ri,level=level,class=class,zone=zone,note=note,online=connected,status=status,token=token,index=i}
            self.members[#self.members+1]=m;self.byName[n]=m
            if connected then online=online+1 end
        end
    end
    table.sort(self.members,function(a,b)
        if a.online~=b.online then return a.online end
        return a.name:lower()<b.name:lower()
    end)
    if not self.frame then return end
    self.title:SetText(name and (safe(name).."  |cff99917c- Guild|r") or "Guild")
    self.guildName:SetText(safe(name or "No guild"));self.rank:SetText(safe(rank or ""))
    self.total:SetText(string.format("|cff68cf79%d online|r  |cffb0a995/ %d members|r",online,#self.members))
    self.rosterTitle:SetText(self.db.offline and "Members" or "Online Members")
    self.rosterCount:SetText(tostring(online).." online")
    self.motdText:SetText(safe(name and (self.demo and self.demo.motd or GetGuildRosterMOTD() or "") or "Join a guild to see its members and chat."))
    self.motdContent:SetHeight(math.max(1,self.motdText:GetStringHeight()+8))
    local canInvite=not self.demo and name and (not CanGuildInvite or CanGuildInvite())
    if canInvite then self.invite:Enable()else self.invite:Disable()end
    self:FilterMembers()
    if self.mode=="INFO" then self:ShowMode("INFO")end
    if self.displayGuild~=name then self.displayGuild=name;self:RebuildChat()end
end
function G:FilterMembers()
    local query=(self.search:GetText() or ""):lower()
    self.filtered={}
    for _,m in ipairs(self.members)do
        if (m.online or self.db.offline) and (query=="" or (m.name.." "..(m.class or "").." "..(m.zone or "")):lower():find(query,1,true))then
            self.filtered[#self.filtered+1]=m
        end
    end
    self.offset=math.min(self.offset,math.max(0,#self.filtered-ROWS))
    self.updatingSlider=true
    self.slider:SetMinMaxValues(0,math.max(0,#self.filtered-ROWS));self.slider:SetValue(self.offset)
    self.updatingSlider=false
    if #self.filtered>ROWS then self.slider:Show()else self.slider:Hide()end
    self:RefreshRows()
end
function G:RefreshRows()
    for i,row in ipairs(self.rows)do
        local m=i<=ROWS and self.filtered[self.offset+i] or nil;row.member=m
        if m then
            row.name:SetText(safe(short(m.name)));row.level:SetText(tostring(m.level or ""))
            local c=self.db.appearance and self.db.appearance.classColors==false and {r=.85,g=.85,b=.85} or classColor(m.token)
            if m.online then row.name:SetTextColor(c.r,c.g,c.b)else row.name:SetTextColor(.45,.45,.45)end
            row.detail:SetText(safe(m.online and ((self.db.appearance and self.db.appearance.zones==false and (m.class or "Online")) or (m.zone and m.zone~="" and m.zone) or (m.class or "Online")) or "Offline"))
            local status=m.online and ((m.status==1 or m.status=="AFK") and "Away" or (m.status==2 or m.status=="DND") and "DnD" or "Online") or "Offline"
            row.status:SetTexture("Interface\\FriendsFrame\\StatusIcon-"..status)
            row:Show()
        else row:Hide()end
    end
    self.rosterEmpty:SetText(#self.filtered==0 and (guild() and "No matching members." or "Not in a guild.") or "")
end
function G:MemberTooltip(row)
    local m=row.member;if not m then return end
    GameTooltip:SetOwner(row,"ANCHOR_LEFT");GameTooltip:SetText(short(m.name),1,.82,0)
    GameTooltip:AddLine(string.format("Level %s %s",tostring(m.level or "?"),m.class or ""),1,1,1)
    if m.rank then GameTooltip:AddLine(m.rank,.8,.8,.8)end
    if m.online and m.zone then GameTooltip:AddLine(m.zone,.65,.85,.65)end
    if m.note and m.note~="" then GameTooltip:AddLine(m.note,.75,.75,.75,true)end
    GameTooltip:AddLine(self.demo and "Screenshot demo member" or (m.online and "Click: whisper   Right-click: options" or "Offline"),.55,.55,.55)
    GameTooltip:Show()
end
function G:MemberClick(row,which)
    if self.demo then return end
    local m=row.member;if not m then return end
    if which=="RightButton" then
        local name=m.name
        EasyMenu({{text=short(name),isTitle=true,notCheckable=true},
            {text="Whisper",notCheckable=true,disabled=not m.online,func=function()ChatFrame_SendTell(name)end},
            {text="Invite to Group",notCheckable=true,disabled=not m.online or short(name)==UnitName("player"),func=function()InviteUnit(name)end},
            {text="View in Original Roster",notCheckable=true,func=function()G:StockRoster(name)end},
            {text="Cancel",notCheckable=true}},self.memberMenu,"cursor",0,0,"MENU")
    elseif m.online then ChatFrame_SendTell(m.name)end
end
function G:ShowMode(mode)
    self.mode=mode
    if mode=="INFO" then
        self.chat:Hide();self.chatEmpty:Hide();self.inputBox:Hide();self.jump:Hide();self.infoScroll:Show()
        local value=guild() and (self.demo and self.demo.info or GetGuildInfoText() or "") or "You are not in a guild."
        self.infoText:SetText(safe(value~="" and value or "No guild information has been set."))
        self.infoContent:SetHeight(math.max(self.infoScroll:GetHeight(),self.infoText:GetStringHeight()+16))
        self.channelTitle:SetText("Guild Information")
    else
        self.infoScroll:Hide();self.chat:Show();self.chatEmpty:Show();self.inputBox:Show()
        self.channelTitle:SetText("Guild Chat")
    end
end
function G:Fit()
    local scale=self.db.scale or 1
    local w,h=self.frame:GetWidth(),self.frame:GetHeight()
    local max=math.min(GetScreenWidth()*.94/w,GetScreenHeight()*.9/h,1.25)
    self.frame:SetScale(math.min(scale,max))
end
function G:Open()
    self.bypass=false
    if FriendsFrame and FriendsFrame:IsShown() and GuildFrame and GuildFrame:IsShown()then
        if HideUIPanel then HideUIPanel(FriendsFrame)else FriendsFrame:Hide()end
        GuildFrame:Hide()
    end
    self.pendingRedirect=false
    self:CreateUI();self:Fit();self.frame:Show();self.frame:Raise()
    self:RequestRoster();self:ReadRoster();self:RebuildChat()
end
function G:Toggle()
    if self.frame and self.frame:IsShown()then self.frame:Hide()else self:Open()end
end
-- StepOnLegos lineage MG-B16E-94A0
function G:StockRoster(member)
    if self.demo then return end
    self.bypass=true;self.pendingRedirect=false
    if self.frame then self.frame:Hide()end
    if FriendsFrame and FriendsFrame:IsShown()then
        if PanelTemplates_SetTab then PanelTemplates_SetTab(FriendsFrame,3)end
        FriendsFrame_ShowSubFrame("GuildFrame")
    else ToggleFriendsFrame(3)end
    if member then
        for i=1,GetNumGuildMembers(true)do
            if GetGuildRosterInfo(i)==member then
                SetGuildRosterSelection(i)
                if GuildStatus_Update then GuildStatus_Update()end
                if GuildMemberDetailFrame then GuildMemberDetailFrame:Show()end
                break
            end
        end
    end
end
function G:Redirect()
    self.pendingRedirect=false
    if not self.db.replace or self.bypass or not GuildFrame or not GuildFrame:IsShown() or not FriendsFrame:IsShown()then return end
    local close=self.frame and self.frame:IsShown()
    if HideUIPanel then HideUIPanel(FriendsFrame)else FriendsFrame:Hide()end
    GuildFrame:Hide()
    if close then self.frame:Hide()else self:Open()end
end
function G:InstallHooks()
    if not GuildFrame or not FriendsFrame or self.hooked then return end
    self.hooked=true
    local function schedule()
        if G.db.replace and not G.bypass and GuildFrame:IsShown()then G.pendingRedirect=true end
    end
    GuildFrame:HookScript("OnShow",schedule);FriendsFrame:HookScript("OnShow",schedule)
    FriendsFrame:HookScript("OnHide",function()G.bypass=false end)
    if FriendsFrame_ShowSubFrame then hooksecurefunc("FriendsFrame_ShowSubFrame",function(name)
        if name=="GuildFrame"then schedule()
        elseif G.frame and G.frame:IsShown()then G.frame:Hide()end
    end)end
end
-- StepOnLegos lineage MG-K75D-20B6
function G:ApplyHotkey()
    if InCombatLockdown and InCombatLockdown()then self.hotkeyPending=true;return end
    self.hotkeyPending=false
    if not self.bindingOwner then self.bindingOwner=CreateFrame("Frame")end
    ClearOverrideBindings(self.bindingOwner)
    -- A temporary default preserves the player's saved G binding. A key
    -- assigned under Key Bindings takes precedence over this default.
    if self.db.defaultG~=false and not GetBindingKey("MODERNGUILD_TOGGLE")then
        SetOverrideBinding(self.bindingOwner,false,"G","MODERNGUILD_TOGGLE")
    end
end
-- Provenance seam MG-R6B9-04D1: pooled legacy roster rows.
function G:EnsureRosterRows(count)
    if count then ROWS=math.max(1,math.min(40,math.floor(count)))end
    for i=#self.rows+1,ROWS do
        local row=CreateFrame("Button",nil,self.right);self.rows[i]=row
        row:SetSize(196,ROW_H);row:SetPoint("TOPLEFT",10,-74-(i-1)*ROW_H);row:RegisterForClicks("LeftButtonUp","RightButtonUp")
        row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight","ADD")
        row.status=row:CreateTexture(nil,"ARTWORK");row.status:SetSize(12,12);row.status:SetPoint("TOPLEFT",0,-5)
        row.name=text(row,"GameFontHighlightSmall","TOPLEFT",18,-3,143)
        row.level=text(row,"GameFontDisableSmall","TOPRIGHT",-2,-3,28);row.level:SetJustifyH("RIGHT")
        row.detail=text(row,"GameFontDisableSmall","TOPLEFT",18,-18,174)
        row:SetScript("OnClick",function(self,which)G:MemberClick(self,which)end)
        row:SetScript("OnEnter",function(self)G.tooltipOwned=true;G:MemberTooltip(self)end)
        row:SetScript("OnLeave",function()if G.tooltipOwned then GameTooltip:Hide();G.tooltipOwned=nil end end)
        row:Hide()
    end
end
function G:CreateUI()
    if self.frame then return end
    local f=CreateFrame("Frame","ModernGuildFrame",UIParent);self.frame=f
    f:SetSize(WIDTH,HEIGHT);f:SetFrameStrata("DIALOG");f:SetFrameLevel(110)
    f:SetClampedToScreen(true);f:SetMovable(true);f:EnableMouse(true);backdrop(f)
    local p=self.db.position
    if type(p)=="table" and type(p.x)=="number" and type(p.y)=="number"then f:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",p.x,p.y)
    else f:SetPoint("CENTER")end
    f:Hide();UISpecialFrames[#UISpecialFrames+1]="ModernGuildFrame"
    f:SetScript("OnHide",function()G.input:ClearFocus();CloseDropDownMenus();if GameTooltip:GetOwner() and G.tooltipOwned then GameTooltip:Hide();G.tooltipOwned=nil end end)
    local header=CreateFrame("Frame",nil,f);self.header=header;header:SetPoint("TOPLEFT",4,-4);header:SetPoint("TOPRIGHT",-44,-4);header:SetHeight(36);header:EnableMouse(true);header:RegisterForDrag("LeftButton")
    header:SetScript("OnDragStart",function()f:StartMoving()end)
    header:SetScript("OnDragStop",function()f:StopMovingOrSizing();G.db.position={x=f:GetLeft(),y=f:GetTop()}end)
    self.title=text(header,"GameFontNormalLarge","LEFT",16,0,850);self.title:SetText("Guild")
    local close=CreateFrame("Button","ModernGuildCloseButton",f,"UIPanelCloseButton");self.closeButton=close
    close:SetSize(32,32);close:SetPoint("TOPRIGHT",-3,-3)
    close:SetFrameStrata("DIALOG");close:SetFrameLevel(f:GetFrameLevel()+20)
    close:EnableMouse(true);close:RegisterForClicks("LeftButtonUp")
    close:SetScript("OnClick",function()f:Hide()end)
    local left=CreateFrame("Frame",nil,f);self.left=left;left:SetWidth(176);left:SetPoint("TOPLEFT",12,-44);left:SetPoint("BOTTOMLEFT",12,43);backdrop(left,true)
    local center=CreateFrame("Frame",nil,f);self.center=center;center:SetPoint("TOPLEFT",left,"TOPRIGHT",8,0);center:SetPoint("BOTTOMLEFT",left,"BOTTOMRIGHT",8,0)
    local right=CreateFrame("Frame",nil,f);self.right=right;right:SetWidth(236);right:SetPoint("TOPRIGHT",-12,-44);right:SetPoint("BOTTOMRIGHT",-12,43);backdrop(right,true)
    center:SetPoint("TOPRIGHT",right,"TOPLEFT",-8,0);backdrop(center,true)
    local emblem=left:CreateTexture(nil,"ARTWORK");emblem:SetSize(44,44);emblem:SetPoint("TOP",0,-16);emblem:SetTexture("Interface\\Icons\\INV_Shirt_GuildTabard_01")
    self.guildName=text(left,"GameFontNormal","TOPLEFT",12,-74,152)
    self.rank=text(left,"GameFontDisableSmall","TOPLEFT",12,-112,152)
    self.total=text(left,"GameFontHighlightSmall","TOPLEFT",12,-136,152)
    local chatButton=button(left,"Guild Chat",150,function()G:ShowMode("CHAT")end);self.chatTab=chatButton;chatButton:SetPoint("TOPLEFT",12,-166)
    local infoButton=button(left,"Guild Information",150,function()G:ShowMode("INFO")end);self.infoTab=infoButton;infoButton:SetPoint("TOPLEFT",12,-195)
    local motdLabel=text(left,"GameFontNormalSmall","TOPLEFT",12,-236,150);motdLabel:SetText("Message of the Day")
    self.motdScroll=CreateFrame("ScrollFrame","ModernGuildMOTDScroll",left,"UIPanelScrollFrameTemplate");self.motdScroll:SetPoint("TOPLEFT",12,-258);self.motdScroll:SetPoint("BOTTOMRIGHT",-29,14)
    self.motdContent=CreateFrame("Frame",nil,self.motdScroll);self.motdContent:SetSize(132,1);self.motdScroll:SetScrollChild(self.motdContent)
    self.motdText=text(self.motdContent,"GameFontHighlightSmall","TOPLEFT",0,0,132)
    self.channelTitle=text(center,"GameFontNormal","TOPLEFT",14,-14,300);self.channelTitle:SetText("Guild Chat");self.channelTitle:SetTextColor(.4,.9,.5)
    self.chat=CreateFrame("ScrollingMessageFrame","ModernGuildChat",center)
    self.chat:SetPoint("TOPLEFT",14,-40);self.chat:SetPoint("BOTTOMRIGHT",-14,64)
    self.chat:SetFontObject(ChatFontNormal);self.chat:SetFading(false);self.chat:SetMaxLines(LIMIT);self.chat:SetJustifyH("LEFT");self.chat:SetSpacing(4)
    self.chat:SetInsertMode("BOTTOM")
    self.chat:EnableMouseWheel(true);self.chat:EnableMouse(true);self.chat:SetHyperlinksEnabled(true)
    self.chat:SetScript("OnHyperlinkClick",function(_,link,label,which)if G.demo and link:match("^player:")then return end;SetItemRef(link,label,which,DEFAULT_CHAT_FRAME)end)
    self.chat:SetScript("OnMouseWheel",function(self,delta)
        if delta>0 then for i=1,3 do self:ScrollUp()end else for i=1,3 do self:ScrollDown()end end
        if self:AtBottom()then G.jump:Hide();G.unread=0 else G.jump:SetText("Jump to latest");G.jump:Show()end
    end)
    self.chatEmpty=text(center,"GameFontDisableSmall","TOPLEFT",14,-46,460)
    self.jump=button(center,"Jump to latest",138,function()G.chat:ScrollToBottom();G.jump:Hide();G.unread=0 end);self.jump:SetPoint("BOTTOM",0,62);self.jump:Hide()
    self.inputBox=CreateFrame("Frame",nil,center);self.inputBox:SetPoint("BOTTOMLEFT",10,12);self.inputBox:SetPoint("BOTTOMRIGHT",-10,12);self.inputBox:SetHeight(36);backdrop(self.inputBox)
    local prefix=text(self.inputBox,"GameFontNormalSmall","LEFT",10,0,36);self.inputPrefix=prefix;prefix:SetText("Guild:");prefix:SetTextColor(.4,.9,.5)
    self.input=CreateFrame("EditBox","ModernGuildChatInput",self.inputBox);self.input:SetPoint("TOPLEFT",52,-7);self.input:SetPoint("BOTTOMRIGHT",-52,7)
    self.input:SetFontObject(ChatFontNormal);self.input:SetAutoFocus(false);self.input:SetMaxLetters(255);self.input:SetHistoryLines(20)
    self.input:SetScript("OnEnterPressed",function()local value=G.input:GetText();if value~=""then G.input:AddHistoryLine(value)end;G:Send()end)
    self.input:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
    self.sendButton=button(self.inputBox,"Send",46,function()G:Send()end);self.sendButton:SetPoint("RIGHT",-4,0)
    self.infoScroll=CreateFrame("ScrollFrame","ModernGuildInfoScroll",center,"UIPanelScrollFrameTemplate");self.infoScroll:SetPoint("TOPLEFT",14,-42);self.infoScroll:SetPoint("BOTTOMRIGHT",-32,16)
    self.infoContent=CreateFrame("Frame",nil,self.infoScroll);self.infoContent:SetSize(450,1);self.infoScroll:SetScrollChild(self.infoContent)
    self.infoText=text(self.infoContent,"GameFontHighlight","TOPLEFT",0,0,450);self.infoScroll:Hide()
    self.rosterTitle=text(right,"GameFontNormalSmall","TOPLEFT",12,-14,140);self.rosterTitle:SetText("Online Members")
    self.rosterCount=text(right,"GameFontDisableSmall","TOPRIGHT",-12,-14,60);self.rosterCount:SetJustifyH("RIGHT")
    self.search=CreateFrame("EditBox","ModernGuildMemberSearch",right,"InputBoxTemplate");self.search:SetPoint("TOPLEFT",18,-38);self.search:SetSize(202,23);self.search:SetAutoFocus(false);self.search:SetMaxLetters(80)
    self.search:SetScript("OnTextChanged",function()G.offset=0;G:FilterMembers()end);self.search:SetScript("OnEscapePressed",function(self)self:SetText("");self:ClearFocus()end)
    self.searchHint=text(self.search,"GameFontDisableSmall","LEFT",1,0,180);self.searchHint:SetText("Search members...")
    self.search:HookScript("OnTextChanged",function(self)if self:GetText()==""then G.searchHint:Show()else G.searchHint:Hide()end end)
    self.slider=CreateFrame("Slider","ModernGuildRosterSlider",right,"UIPanelScrollBarTemplate");self.slider:SetPoint("TOPRIGHT",-12,-90);self.slider:SetPoint("BOTTOMRIGHT",-12,54);self.slider:SetWidth(14);self.slider:SetMinMaxValues(0,0);self.slider:SetValueStep(1)
    self.slider:SetScript("OnValueChanged",function(_,value)if not G.updatingSlider then G.offset=math.floor(value+.5);G:RefreshRows()end end)
    right:EnableMouseWheel(true);right:SetScript("OnMouseWheel",function(_,delta)G.offset=math.max(0,math.min(math.max(0,#G.filtered-ROWS),G.offset-delta*3));G.slider:SetValue(G.offset)end)
    self.memberMenu=CreateFrame("Frame","ModernGuildMemberMenu",UIParent,"UIDropDownMenuTemplate")
    self:EnsureRosterRows()
    self.rosterEmpty=text(right,"GameFontDisableSmall","TOPLEFT",15,-84,196)
    self.offline=CreateFrame("CheckButton",nil,right,"UICheckButtonTemplate");self.offline:SetSize(22,22);self.offline:SetPoint("BOTTOMLEFT",8,10);self.offline:SetChecked(self.db.offline)
    local offlineLabel=text(self.offline,"GameFontHighlightSmall","LEFT",24,0,160);offlineLabel:SetText("Show offline members")
    self.offline:SetScript("OnClick",function(self)G.db.offline=self:GetChecked() and true or false;G.offset=0;G:ReadRoster()end)
    local original=button(f,"Original Roster",140,function()G:StockRoster()end);original:SetPoint("BOTTOMLEFT",14,11)
    self.invite=button(f,"Invite Member",130,function()if not G.demo and guild() and (not CanGuildInvite or CanGuildInvite())then StaticPopup_Show("MODERNGUILD_INVITE")end end);self.invite:SetPoint("BOTTOMRIGHT",-14,11)
    local help=text(f,"GameFontDisableSmall","BOTTOMLEFT",172,17,600);self.helpText=help;help:SetText("G: open / close  |  Drag the title bar to move  |  /mg")
    self.filtered={};self:ShowMode("CHAT")
end
function G:Slash(msg)
    local cmd,arg=(msg or ""):match("^%s*(%S*)%s*(.-)%s*$");cmd=cmd:lower()
    if cmd==""then self:Toggle()
    elseif cmd=="original" or cmd=="roster"then self:StockRoster()
    elseif cmd=="on" or cmd=="off"then self.db.replace=cmd=="on";self.pendingRedirect=false;if cmd=="off" and self.frame then self.frame:Hide()end;say("Guild-panel replacement "..cmd..".")
    elseif cmd=="key"then
        if arg=="off" or arg=="on"then self.db.defaultG=arg=="on";self:ApplyHotkey();say("Default G shortcut "..arg..".")else say("Use /mg key on or /mg key off. Custom shortcuts are in Key Bindings > Modern Guild.")end
    elseif cmd=="reset"then self.db.position=nil;self.db.scale=1;self:CreateUI();self.frame:ClearAllPoints();self.frame:SetPoint("CENTER");self:Fit()
    elseif cmd=="scale"then local n=tonumber(arg);if n and n>=.65 and n<=1.25 then self.db.scale=n;self:CreateUI();self:Fit()else say("Use /mg scale 0.65 through 1.25")end
    else say("G or /mg: toggle. Options: original, on, off, reset, key on/off, scale 0.65-1.25.")end
end
StaticPopupDialogs.MODERNGUILD_INVITE={text="Invite a player to the guild",button1=ACCEPT,button2=CANCEL,hasEditBox=true,maxLetters=48,timeout=0,whileDead=true,hideOnEscape=true,
    OnAccept=function(self)local name=self.editBox:GetText():match("^%s*(.-)%s*$");if name~="" and not G.demo and guild() and (not CanGuildInvite or CanGuildInvite())then GuildInvite(name)end end,
    OnShow=function(self)self.editBox:SetText("");self.editBox:SetFocus()end,
    EditBoxOnEnterPressed=function(self)local popup=self:GetParent();StaticPopupDialogs.MODERNGUILD_INVITE.OnAccept(popup);popup:Hide()end,
    EditBoxOnEscapePressed=function(self)self:GetParent():Hide()end}
local events=CreateFrame("Frame")
for _,event in ipairs({"ADDON_LOADED","PLAYER_LOGIN","PLAYER_GUILD_UPDATE","GUILD_ROSTER_UPDATE","GUILD_MOTD","CHAT_MSG_GUILD","DISPLAY_SIZE_CHANGED","UPDATE_BINDINGS","PLAYER_REGEN_ENABLED"})do events:RegisterEvent(event)end
events:SetScript("OnEvent",function(_,event,...)
    if event=="ADDON_LOADED"then
        local name=...
        if name==addonName then
            ModernGuildDB=ModernGuildDB or {};G.db=ModernGuildDB
            if G.db.replace==nil then G.db.replace=true end
            if type(G.db.history)~="table"then G.db.history={}end
            if type(G.db.scale)~="number" or G.db.scale<.65 or G.db.scale>1.25 then G.db.scale=1 end
            SLASH_MODERNGUILD1="/mg";SLASH_MODERNGUILD2="/modernguild";SlashCmdList.MODERNGUILD=function(msg)G:Slash(msg)end
        end
        if G.db then G:InstallHooks()end
    elseif not G.db then return
    elseif event=="PLAYER_LOGIN"then G:InstallHooks();G:ApplyHotkey();G:ReadRoster();G:RequestRoster()
    elseif event=="UPDATE_BINDINGS" or event=="PLAYER_REGEN_ENABLED"then G:ApplyHotkey()
    elseif event=="CHAT_MSG_GUILD"then G:AddChat(...)
    elseif event=="DISPLAY_SIZE_CHANGED"then if G.frame then G:Fit()end
    else G.rosterDirty=true;if event=="PLAYER_GUILD_UPDATE"then G:RequestRoster()end end
end)
events:SetScript("OnUpdate",function(_,dt)
    if not G.db then return end
    if G.pendingRedirect then G:Redirect()end
    G.elapsed=G.elapsed+dt
    if G.elapsed>=.25 then
        G.elapsed=0
        if G.rosterDirty then G.rosterDirty=false;G:ReadRoster()end
        if G.frame and G.frame:IsShown()then G:RequestRoster()end
    end
end)
