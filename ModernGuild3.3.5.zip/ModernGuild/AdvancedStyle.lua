-- StepOnLegos / MG-SOL-7C92A4E1 / advanced palette leaf MG-A7B2-43E0.
local G=ModernGuild
local fonts={{name="Friz Quadrata",path="Fonts\\FRIZQT__.TTF"},{name="Arial",path="Fonts\\ARIALN.TTF"},{name="Morpheus",path="Fonts\\MORPHEUS.TTF"},{name="Skurri",path="Fonts\\SKURRI.TTF"}}
local edges={{name="Tooltip",path="Interface\\Tooltips\\UI-Tooltip-Border",size=12},{name="Dialog",path="Interface\\DialogFrame\\UI-DialogBox-Border",size=16},{name="Minimal",path="Interface\\Buttons\\WHITE8X8",size=1}}
local function color(v,fallback)
    if type(v)~="table"then return fallback end
    for i=1,3 do if type(v[i])~="number" or v[i]~=v[i]or v[i]<0 or v[i]>1 then return fallback end end
    return v
end
function G:AdvancedAppearance()
    local a=self:Appearance()
    if a.styleNative==nil then a.styleNative=true end
    if type(a.fontIndex)~="number"or not fonts[a.fontIndex]then a.fontIndex=1 end
    if type(a.edgeIndex)~="number"or not edges[a.edgeIndex]then a.edgeIndex=1 end
    if a.outline~="OUTLINE"and a.outline~="THICKOUTLINE"then a.outline=""end
    if type(a.lineSpacing)~="number"or a.lineSpacing~=a.lineSpacing then a.lineSpacing=4 end
    a.lineSpacing=math.max(0,math.min(12,a.lineSpacing))
    a.accent=color(a.accent,nil);a.background=color(a.background,nil);a.border=color(a.border,nil)
    return a
end
function G:AdvancedLayout()
    if not self.layoutReady then return end
    local a=self:AdvancedAppearance();local w=self.frame:GetWidth()
    if a.hideLeft then self.left:Hide()else self.left:Show()end
    if a.hideRight then self.right:Hide()else self.right:Show()end
    local l=a.hideLeft and 12 or a.leftWidth+20
    local r=a.hideRight and 12 or self.right:GetWidth()+20
    self.center:ClearAllPoints();self.center:SetPoint("TOPLEFT",self.frame,"TOPLEFT",l,-44);self.center:SetPoint("BOTTOMRIGHT",self.frame,"BOTTOMRIGHT",-r,43)
    local cw=w-l-r
    self.infoContent:SetWidth(math.max(240,cw-48));self.infoText:SetWidth(math.max(240,cw-48));self.infoContent:SetHeight(math.max(1,self.infoText:GetStringHeight()+16))
    self.chatEmpty:SetWidth(math.max(200,cw-28));self.channelTitle:SetWidth(math.max(140,cw-28))
    local font=fonts[a.fontIndex].path
    self.chat:SetFont(font,a.fontSize,a.outline);self.input:SetFont(font,a.fontSize,a.outline);self.chat:SetSpacing(a.lineSpacing)
    local edge=edges[a.edgeIndex]
    local palette=self:ThemePalette();local bg=a.background or palette.bg;local border=a.border or palette.edge
    for _,p in ipairs({self.frame,self.left,self.center,self.right,self.inputBox})do
        p:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile=edge.path,tile=true,tileSize=16,edgeSize=edge.size,insets={left=3,right=3,top=3,bottom=3}})
        p:SetBackdropColor(bg[1],bg[2],bg[3],p==self.frame and a.opacity*.35 or a.opacity)
        p:SetBackdropBorderColor(border[1],border[2],border[3],math.min(1,a.opacity+.2))
    end
    if a.accent then
        for _,t in ipairs({self.title,self.guildName,self.channelTitle,self.rosterTitle})do t:SetTextColor(unpack(a.accent))end
    end
    local n=self.nativeChat
    if n and n.active then
        if a.styleNative and n.selected then
            for _,target in ipairs({n.selected,n.editBox})do
                local saved=n.saved[target]
                if saved and not saved.font then
                    saved.font={target:GetFont()}
                    if target.GetSpacing then saved.spacing=target:GetSpacing()end
                end
                target:SetFont(font,a.fontSize,a.outline)
                if target==n.selected then target:SetSpacing(a.lineSpacing)end
            end
        elseif not a.styleNative then
            for target,saved in pairs(n.saved)do
                if saved.font then target:SetFont(unpack(saved.font));saved.font=nil end
                if saved.spacing~=nil then target:SetSpacing(saved.spacing);saved.spacing=nil end
            end
        end
    end
end
function G:PickColor(key)
    if not ColorPickerFrame then return end
    if self.nativeChat and self.nativeChat.editBox then self.nativeChat.editBox:ClearFocus()end
    if self.input then self.input:ClearFocus()end
    local a=self:AdvancedAppearance()
    local original=a[key]and {unpack(a[key])}or nil
    local initial=a[key]or (key=="accent"and {.94,.78,.43}or key=="border"and {.48,.41,.28}or {.05,.05,.05})
    ColorPickerFrame:Hide();ColorPickerFrame.hasOpacity=false
    ColorPickerFrame.func=function()a[key]={ColorPickerFrame:GetColorRGB()};G:ApplyAppearance()end
    ColorPickerFrame.cancelFunc=function()a[key]=original;G:ApplyAppearance()end
    ColorPickerFrame:SetColorRGB(unpack(initial));ColorPickerFrame:Show()
end
local function text(f,s,y)local t=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");t:SetPoint("TOPLEFT",20,y);t:SetWidth(330);t:SetJustifyH("LEFT");t:SetText(s);return t end
function G:OpenAdvancedStyle()
    self:CreateUI()
    if self.nativeChat and self.nativeChat.editBox then self.nativeChat.editBox:ClearFocus()end
    self.input:ClearFocus()
    if self.advancedStyle and self.advancedStyle:IsShown()then self.advancedStyle:Hide();return end
    if not self.advancedStyle then
        local f=CreateFrame("Frame","ModernGuildAdvancedStyle",UIParent);self.advancedStyle=f
        f:SetSize(380,530);f:SetPoint("CENTER");f:SetFrameStrata("DIALOG");f:SetFrameLevel(self.frame:GetFrameLevel()+50);f:SetClampedToScreen(true);f:EnableMouse(true)
        f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",tile=true,tileSize=16,edgeSize=12,insets={left=3,right=3,top=3,bottom=3}});f:SetBackdropColor(.05,.05,.05,1)
        local c=CreateFrame("Button",nil,f,"UIPanelCloseButton");c:SetPoint("TOPRIGHT",-2,-2);c:SetScript("OnClick",function()f:Hide()end)
        UISpecialFrames[#UISpecialFrames+1]="ModernGuildAdvancedStyle"
        text(f,"Modern Guild - More Style",-20)
        local function b(label,y,fn)local v=CreateFrame("Button",nil,f,"UIPanelButtonTemplate");v:SetSize(330,25);v:SetPoint("TOPLEFT",25,y);v:SetText(label);v:SetScript("OnClick",fn);return v end
        f.font=b("Font",-58,function()local a=G:AdvancedAppearance();a.fontIndex=a.fontIndex%#fonts+1;a.styleNative=true;G:ApplyAppearance();G:SyncAdvancedStyle()end)
        f.outline=b("Outline",-92,function()local a=G:AdvancedAppearance();a.outline=a.outline==""and "OUTLINE"or a.outline=="OUTLINE"and "THICKOUTLINE"or "";G:ApplyAppearance();G:SyncAdvancedStyle()end)
        f.edge=b("Border",-126,function()local a=G:AdvancedAppearance();a.edgeIndex=a.edgeIndex%#edges+1;G:ApplyAppearance();G:SyncAdvancedStyle()end)
        b("Choose Accent Color",-166,function()G:PickColor("accent")end)
        b("Choose Background Color",-200,function()G:PickColor("background")end)
        b("Choose Border Color",-234,function()G:PickColor("border")end)
        f.spacing=b("Line Spacing",-268,function()local a=G:AdvancedAppearance();a.lineSpacing=(a.lineSpacing+2)%14;G:ApplyAppearance();G:SyncAdvancedStyle()end)
        f.checks={}
        for i,spec in ipairs({{"hideLeft","Hide guild sidebar"},{"hideRight","Hide member sidebar"},{"styleNative","Apply this font to native chat"}})do
            local key,label=unpack(spec);local check=CreateFrame("CheckButton",nil,f,"UICheckButtonTemplate");f.checks[key]=check;check:SetSize(24,24);check:SetPoint("TOPLEFT",20,-310-(i-1)*30)
            local t=check:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");t:SetPoint("LEFT",26,0);t:SetText(label)
            check:SetScript("OnClick",function(self)G:AdvancedAppearance()[key]=self:GetChecked()and true or false;G:ApplyAppearance()end)
        end
        text(f,"Font changes also apply to docked chat.\nCustom colors override the selected theme.",-410)
        b("Clear Custom Colors",-470,function()local a=G:AdvancedAppearance();a.accent=nil;a.background=nil;a.border=nil;G:ApplyAppearance()end)
    end
    if self.settings then self.settings:Hide()end
    self:SyncAdvancedStyle();self.advancedStyle:Show();self.advancedStyle:Raise()
end
function G:SyncAdvancedStyle()
    if not self.advancedStyle then return end
    local f=self.advancedStyle;local a=self:AdvancedAppearance()
    f.font:SetText("Font: "..fonts[a.fontIndex].name);f.outline:SetText("Outline: "..(a.outline==""and "None"or a.outline));f.edge:SetText("Border: "..edges[a.edgeIndex].name);f.spacing:SetText("Line Spacing: "..a.lineSpacing)
    for k,v in pairs(f.checks)do v:SetChecked(a[k])end
end
local layout=G.Layout
function G:Layout()layout(self);self:AdvancedLayout()end
local open=G.OpenSettings
function G:OpenSettings()
    if self.nativeChat and self.nativeChat.editBox then self.nativeChat.editBox:ClearFocus()end
    if self.input then self.input:ClearFocus()end
    open(self)
    if self.settings and not self.settings.moreStyle then
        self.settings:SetHeight(620)
        local b=CreateFrame("Button",nil,self.settings,"UIPanelButtonTemplate");self.settings.moreStyle=b
        b:SetSize(330,24);b:SetPoint("TOPLEFT",25,-502);b:SetText("More Style...");b:SetScript("OnClick",function()G:OpenAdvancedStyle()end)
    end
end
local create=G.CreateUI
function G:CreateUI()
    create(self)
    if not self._advancedCloseHook then self._advancedCloseHook=true;self.frame:HookScript("OnHide",function()if G.advancedStyle then G.advancedStyle:Hide()end end)end
end
