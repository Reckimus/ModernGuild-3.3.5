-- StepOnLegos provenance MG-D58C-903E. Local screenshot fixtures only.
local G=ModernGuild
local worldMessages={}
local function fixture()
    local d={name="The Silver Lantern",motd="Adventure is better together! Dungeon night at 8. Bring potions, good stories, and your best transmog.",info="The Silver Lantern\n\nA friendly band of adventurers exploring Azeroth together.\n\nDungeon nights: Friday and Sunday\nEveryone is welcome to join the next adventure.",members={},history={},world=worldMessages,view="GUILD",drafts={}}
    local names={"Aeloria","Bramblefoot","Cindervale","Duskwalker","Emberlyn","Frostwhisper","Glimmerwick","Hearthstone","Ironbloom","Juniper","Kaelthorn","Lunara","Mistgrove","Northwind","Oakenshield","Pipwick","Riverstone","Starfall","Thistledown","Willowmere","Zephyrine","Amberforge","Brightbrook","Cloudstep"}
    local classes={{"Paladin","PALADIN"},{"Ranger","HUNTER"},{"Mage","MAGE"},{"Rogue","ROGUE"},{"Priest","PRIEST"},{"Druid","DRUID"},{"Warlock","WARLOCK"},{"Warrior","WARRIOR"},{"Shaman","SHAMAN"}}
    local zones={"Stormwind City","Elwynn Forest","Redridge Mountains","Duskwood","Ironforge","Stranglethorn Vale"}
    for i,n in ipairs(names)do
        local c=classes[(i-1)%#classes+1]
        d.members[i]={name=n,rank=i==1 and "Guild Master" or (i<5 and "Officer" or "Adventurer"),rankIndex=i==1 and 0 or 2,level=60-(i%4)*3,class=c[1],token=c[2],zone=zones[(i-1)%#zones+1],online=i<=18,status=i==7 and "AFK" or nil,note="Ready for the next adventure."}
    end
    local lines={
        {1,"Evening, everyone! Who is ready for an adventure?"},{2,"Just finished my quests. Count me in!"},{3,"I can bring the portals and questionable life advice."},{4,"That sounds like our kind of dungeon run."},{5,"Healer ready. Please remember your potions this time :)"},{6,"I made extra food for the group."},{7,"Anyone need bags before we head out?"},{8,"Yes please! My inventory is mostly crafting materials."},{9,"Mostly? I saw those twelve fishing poles."},{10,"You never know when a fishing emergency will happen."},{11,"Tank ready whenever you are."},{12,"The sunset in Elwynn looks amazing tonight."},{13,"Stopping for a screenshot on the way!"},{14,"Welcome back, everyone."},{15,"Thanks! Good to see the guild so busy."},{16,"Group one is nearly full. One more damage dealer?"},{17,"I can join after I turn in this quest."},{18,"Perfect. We will meet at the flight master."},{1,"No rush. This is supposed to be fun."},{3,"Famous last words before Bramble pulls the whole room."},{2,"That only happened twice!"},{5,"Three times. I kept notes."},{6,"All right, food and buffs are ready."},{1,"Let's make it a good run. For the Silver Lantern!"}}
    local now=time()
    for i,v in ipairs(lines)do local m=d.members[v[1]];d.history[i]={author=m.name,class=m.token,message=v[2],at=now-(#lines-i)*48}end
    return d
end
function G:SetDemo(enabled,view)
    if enabled then
        if not self.demo then
            self.demo=fixture()
            self.demo.previousDraft=self.input and self.input:GetText() or ""
            self.demo.previousSearch=self.search and self.search:GetText() or ""
        end
        self:Open();self.search:SetText("");self.offset=0;self:ReadRoster();self:RebuildChat();self.input:SetText("");self.input:ClearFocus()
        if view=="WORLD"then self.nativeChat:ChooseWindow("DEMO_WORLD")end
    elseif self.demo then
        local d=self.demo;self.demo=nil
        self.offset=0;self:Open();self.search:SetText(d.previousSearch);self.input:SetText(d.previousDraft);self:ReadRoster();self:RebuildChat();self:RequestRoster()
    end
end
local send=G.Send
function G:Send()
    if not self.demo then return send(self)end
    if self.demo.view=="WORLD"then return end
    local value=self.input:GetText():match("^%s*(.-)%s*$")
    if value~="" then
        value=value:gsub("|","||")
        local history=self:GetHistory()
        history[#history+1]={author="Aeloria",class="PALADIN",message=value,at=time()}
        if #history>300 then table.remove(history,1)end
        self:RebuildChat();self.input:SetText("")
    end
    if self:Appearance().keepFocus then self.input:SetFocus()else self.input:ClearFocus()end
end
local slash=G.Slash
function G:Slash(value)
    local cmd,arg=(value or ""):match("^%s*(%S*)%s*(.-)%s*$")
    if cmd:lower()=="demo"then
        arg=arg:lower()
        if arg=="world"then self:SetDemo(true,"WORLD")
        elseif arg=="guild"then self:SetDemo(true)
        elseif arg=="off"then self:SetDemo(false)
        elseif arg=="on"then self:SetDemo(true)
        elseif arg==""then self:SetDemo(not self.demo)end
    else return slash(self,value)end
end
-- Demo selectors never borrow real channel messages or recipient inputs.
local N=G.nativeChat
local history=G.GetHistory
function G:GetHistory()
    if self.demo and self.demo.view=="WORLD"then return self.demo.world end
    return history(self)
end
local format=G.FormatMessage
function G:FormatMessage(record)
    local value=format(self,record)
    if self.demo and self.demo.view=="WORLD"then
        value=value:gsub("|cff40ed77","|cff70c7ff")
        return "|cff70c7ff["..tostring(record.channelIndex or "")..". World]|r "..value
    end
    return value
end
local choose=N.ChooseWindow
function N:ChooseWindow(id)
    if G.demo then
        local d=G.demo
        d.drafts[d.view]=G.input:GetText()
        d.view=id=="DEMO_WORLD"and "WORLD"or "GUILD"
        choose(self,"HISTORY")
        G:RebuildChat();G.input:SetText(d.drafts[d.view]or "")
        if d.view=="WORLD"then G.input:ClearFocus()end
        return
    end
    return choose(self,id)
end
local apply=N.ApplyView
function N:ApplyView()if G.demo then self:Config().selected="HISTORY"end;return apply(self)end
local menu=N.ViewMenu
function N:ViewMenu()
    if not G.demo then return menu(self)end
    EasyMenu({{text="Chat Windows",isTitle=true,notCheckable=true},
        {text="Guild Chat",checked=G.mode=="CHAT"and G.demo.view=="GUILD",func=function()N:ChooseWindow("HISTORY")end},
        {text="World Chat",checked=G.mode=="CHAT"and G.demo.view=="WORLD",func=function()N:ChooseWindow("DEMO_WORLD")end},
        {text="Guild Information",notCheckable=true,func=function()G:ShowMode("INFO")end}},self.menu,"cursor",0,0,"MENU")
end
local mode=G.ShowMode
function G:ShowMode(value)
    mode(self,value)
    if self.demo then
        local world=self.demo.view=="WORLD"
        N.bar:Show();N.viewButton:SetText(world and "World Chat"or "Guild Chat");N.channelButton:Hide()
        self.channelTitle:Hide();self.inputPrefix:SetText(world and "World:"or "Guild:");self.inputPrefix:SetWidth(world and 230 or 36)
        if value=="CHAT"then
            if world then
                self.input:Hide();self.sendButton:Hide()
                self.inputPrefix:SetText("World chat - live preview")
            else self.input:Show();self.sendButton:Show()end
        end
    elseif self.inputPrefix then self.inputPrefix:SetText("Guild:");self.inputPrefix:SetWidth(36);self.sendButton:Show()end
end
local open=G.Open
function G:Open()
    if self.demo then self.demo.view="GUILD"end
    return open(self)
end

-- Session-only World preview. No registration changes to any native chat window.
local feed=CreateFrame("Frame")
feed:RegisterEvent("CHAT_MSG_CHANNEL")
feed:SetScript("OnEvent",function(_,_,message,author,language,channel,target,flags,zoneChannelID,channelIndex,channelName)
    local name=type(channelName)=="string"and channelName or ""
    if name==""and type(channel)=="string"then name=channel:gsub("^%d+%.%s*","")end
    if name:lower()~="world"or type(message)~="string"or type(author)~="string"then return end
    local record={author=author,message=message,at=time(),channelIndex=tonumber(channelIndex)or 2}
    worldMessages[#worldMessages+1]=record
    while #worldMessages>300 do table.remove(worldMessages,1)end
    if G.demo and G.demo.view=="WORLD"and G.chat then
        local bottom=G.chat:AtBottom()
        G.chat:AddMessage(G:FormatMessage(record),.44,.78,1);G.chatEmpty:SetText("")
        if bottom then G.chat:ScrollToBottom()end
    end
end)
G.demoWorldFeed=feed
local rebuild=G.RebuildChat
function G:RebuildChat()
    rebuild(self)
    if self.demo and self.demo.view=="WORLD"and #worldMessages==0 then
        self.chatEmpty:SetText("Live World chat will appear here as messages arrive. Join World in the game's chat settings if needed.")
    end
end
